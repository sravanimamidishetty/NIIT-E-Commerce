package com.spring.dao;

import com.spring.model.Product;

public interface ProductDAO {
	
	public boolean saveProduct(Product product);
	

}
