package com.spring.dao;

import com.spring.model.Category;


public interface CategoryDAO {
	public boolean saveCategory(Category category);

}
